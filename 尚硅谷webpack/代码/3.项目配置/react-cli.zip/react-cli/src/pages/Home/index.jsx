import React from "react";
import "./index.less";

export default function Home() {
  return <h1 className="home-title">Home~~~</h1>;
}
